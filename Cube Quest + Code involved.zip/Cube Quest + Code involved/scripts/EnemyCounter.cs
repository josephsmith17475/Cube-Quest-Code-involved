﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class EnemyCounter : MonoBehaviour
{
    int EnemiesLeft = 0;
    public Text TextCount;
    public GameObject WinCutscene;

    void Start()
    {
        EnemiesLeft = 10;
    }
    void Update()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("EnimHit");
        EnemiesLeft = enemies.Length;
        TextCount.text = "Ememies = " + enemies.Length.ToString();
        
        if (EnemiesLeft == 0)
        {
            WinCutscene.SetActive(true);
        }
    }
}
