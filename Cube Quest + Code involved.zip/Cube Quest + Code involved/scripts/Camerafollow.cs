﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camerafollow : MonoBehaviour
{
    public Transform target;//this will act as the target for the camera and it will track the target
    public float Smooth = 0.125f;//this is the value of the smoothing and i made this public so it can be edited outside of unity
    public Vector3 offset;//this allows me to offset the camera from  the player to get the right angle

    void Update()
    {
        Vector3 DesiredPos = target.position + offset;//this sets the base position of the camera without the smoothing
        Vector3 SmoothPos = Vector3.Lerp(transform.position, DesiredPos, Smooth);//the lerp will basically interpret the point between all 3 values
        transform.position = SmoothPos;
    }

}
