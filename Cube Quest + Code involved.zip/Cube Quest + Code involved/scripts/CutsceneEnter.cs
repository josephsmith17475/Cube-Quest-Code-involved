﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutsceneEnter : MonoBehaviour
{
    public GameObject player;//allows me to disable the player movement when triggered
    public GameObject cutcam;//allows the cutscene camera to be viewed when triggered and not the main camera
    public GameObject cutsceneobj;//makes all cutscene based objects in the scene active
    public GameObject cutsceneobj2;

    void OnTriggerEnter(Collider other)
    {
        this.gameObject.GetComponent<BoxCollider>().enabled = false;//stops the cutscene trigger from triggering again once its finished
        cutcam.SetActive(true);//activates cutscene camera
        player.SetActive(false);//stops player movement and visibility
        cutsceneobj.SetActive(true);//cutscene objects are now able to be seen
        cutsceneobj2.SetActive(false);
        StartCoroutine(finishcut());//would allow for the code to be stopped or paused in the middle of being executed
    }
    IEnumerator finishcut()
    {
        yield return new WaitForSeconds(7.14f);//7.14 frames is the length of the animation and what this does is stops the animation
        cutcam.SetActive(false);
        player.SetActive(true);
        cutsceneobj.SetActive(false);
        cutsceneobj2.SetActive(true);
    }
}
