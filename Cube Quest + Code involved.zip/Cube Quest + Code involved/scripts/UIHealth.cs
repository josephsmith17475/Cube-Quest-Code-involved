﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHealth : Healthbar
{
    public Text HealthText;

    void Update()
    {
        HealthText.text = slid.value.ToString();
    }
}
