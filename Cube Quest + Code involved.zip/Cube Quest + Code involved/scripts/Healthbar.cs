﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Healthbar : MonoBehaviour
{
   public Slider slid;

   public void HealthNum(int health)
   {
       slid.value = health;
   }
   public void MaxHealthNum(int health)
   {
       slid.maxValue = health;
       slid.value = health;
   }
   
}