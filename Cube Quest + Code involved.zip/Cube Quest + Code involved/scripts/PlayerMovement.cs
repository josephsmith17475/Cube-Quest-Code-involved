using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public int MaxHealth = 100;
    public int health;
    //allows me to change value aspects of the chartacter without having to code it, speed value
    public float moveSpeed = 5f;
    //manually calling the object through unity.
    public Rigidbody rb;
    public Vector3 moveDirection;
    public Animator animator;
    public Healthbar HealthBar;
    public GameObject GameOverCut;


    void Start()
    {
        health = MaxHealth;
        HealthBar.MaxHealthNum(MaxHealth);
    }
    void Update()
    {
        ControllPlayer();
    }
     void ControllPlayer()
     {
         // registering the movement as a value and getting it from vertical and horizontal axis
         float moveHorizontal = Input.GetAxisRaw ("Horizontal");
         float moveVertical = Input.GetAxisRaw ("Vertical");
 
         Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
         //would rotate the character according to where the theyre are heading and adds a smoothness once the player starts to change direction
         if(movement != Vector3.zero) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(movement.normalized), 0.15f); 
 
         transform.Translate (movement * moveSpeed * Time.deltaTime, Space.World);
     }
     void TakeDamage(int damage)
     {
         health -= damage;
         HealthBar.HealthNum(health);
     }
     void OnTriggerEnter(Collider other)
     {
         if(other.gameObject.name == "enemy sword")
         {
             if (other.tag == "Enemy")
             TakeDamage(10);
             if (other.tag == "Enemy")//any object at all with the tag
             {
                 animator.SetTrigger("IsAttacked");
                 moveDirection = rb.transform.position - other.transform.position;
                 rb.AddForce(moveDirection.normalized * +2000f);
             }
             if (health <= 0)
             {
                 GameOverCut.SetActive(true);
             }
         }
     }
}
