﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProceduralDungeon : MonoBehaviour
{
    public int openingDirection;
    //1 = Need B opening
    //2 = Need T opening
    //3 = Need L opening
    //4 = Need R opening

    private RoomTemplates templates;
    private int random;
    private bool spawned = false;

    void Start()
    {
        templates = GameObject.FindGameObjectWithTag("Rooms").GetComponent<RoomTemplates>();
        Invoke("Spawn", 0.5f);
    }
    void Spawn()
    {
        if(spawned == false)
        {
            if(openingDirection == 1)
            {
                random = Random.Range(0, templates.bottomRooms.Length);
                Instantiate(templates.bottomRooms[random], transform.position, templates.bottomRooms[random].transform.rotation);
            }
            else if(openingDirection == 2)
            {
                random = Random.Range(0, templates.topRooms.Length);
                Instantiate(templates.topRooms[random], transform.position, templates.topRooms[random].transform.rotation);
            }
            else if(openingDirection == 3)
            {
                random = Random.Range(0, templates.leftRooms.Length);
                Instantiate(templates.leftRooms[random], transform.position, templates.leftRooms[random].transform.rotation);
            }
            else if(openingDirection == 4)
            {
                random = Random.Range(0, templates.rightRooms.Length);
                Instantiate(templates.rightRooms[random], transform.position, templates.rightRooms[random].transform.rotation);
            }
            spawned = true;
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("SpawnPoint"))
        { 
            if(other.GetComponent<ProceduralDungeon>().spawned == false && spawned == false)
            {
                Instantiate(templates.closedRoom, transform.position, Quaternion.identity);
                Destroy(gameObject);
            }
            spawned = true;
        }
    }
}
