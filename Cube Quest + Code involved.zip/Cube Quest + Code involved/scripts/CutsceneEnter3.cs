﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutsceneEnter3 : MonoBehaviour
{
    public GameObject player;
    public GameObject cutsceneobj;

    void OnTriggerEnter(Collider other)
    {
        this.gameObject.GetComponent<BoxCollider>().enabled = false;
        player.SetActive(false);
        cutsceneobj.SetActive(true);
    }
    IEnumerator finishcut()
    {
        yield return new WaitForSeconds(26.31f);
        player.SetActive(true);
        cutsceneobj.SetActive(false);
    }
}
