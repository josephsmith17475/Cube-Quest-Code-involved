﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enimtarget : MonoBehaviour
{
    public static enimtarget instance;

    void Awake()
    {
        instance = this;
    }

    public GameObject player;

}
