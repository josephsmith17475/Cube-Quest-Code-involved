﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class objectiveanim : MonoBehaviour
{
    public GameObject text;
    public GameObject animtexttwo;

    void OnTriggerEnter(Collider other)
    {
        this.gameObject.GetComponent<BoxCollider>().enabled = false;
        text.SetActive(true);
        StartCoroutine(Wait());
    }
    IEnumerator Wait()
    {
        yield return new WaitForSeconds(10f);
        text.SetActive(false);
        animtexttwo.SetActive(true);
        yield return new WaitForSeconds(1f);
        animtexttwo.SetActive(false);
    }

}
