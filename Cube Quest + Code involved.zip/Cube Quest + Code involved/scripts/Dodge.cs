﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dodge : MonoBehaviour
{
    public float dashspeed;//this allows the value of the dodge speed to be changed in unity rather than the code
    Rigidbody rig;
    bool isdash;//checks to see if the player is currently dodging
    public ParticleSystem particles;//allows me to attach the particles to the script so then the script knows what particles to use
    void Start()
    {
        rig = GetComponent<Rigidbody>();
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            isdash = true;//checks if the player presses the dodge button and if they did then activate dodge
        if (Input.GetKeyDown(KeyCode.Space))
            particles.Play();
    }
    private void FixedUpdate()
    {
        if (isdash)
            dashing();//will update every frame when isdash is true
    }

    private void dashing()
    {
        rig.AddForce(transform.forward * dashspeed, ForceMode.Impulse);
        isdash = false;// will force the player forward then set isdash to false
    }


}
