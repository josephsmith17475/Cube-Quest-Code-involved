﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class attack : MonoBehaviour
{
    //this will allow us to attach the animator component to the script allowing the trigger to affect the animator
    public Animator animator;
    
    void Update()
    {
        //will check every frame if the the user pressed mouse0(left mouse click) and if so then trigger attack
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            Attack();
        }
    }
    //this sets the animation preset attack to a trigger.
    void Attack()
    {
        animator.SetTrigger("Attack");
    }
    IEnumerator OnTriggerEnter(Collider other)
    {
        if (other.tag == "EnimHit")
        {
            GetComponent<Collider>().enabled = false;
            yield return new WaitForSeconds(0.04f);
            GetComponent<Collider>().enabled = true;
        }
    }
}
