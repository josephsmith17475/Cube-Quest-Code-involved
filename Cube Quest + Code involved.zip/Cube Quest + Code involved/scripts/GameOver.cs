﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    public GameObject world;
    public GameObject GameOverCutscene;

    // Start is called before the first frame update
    IEnumerator Start()
    {
        world.SetActive(false);
        GameOverCutscene.SetActive(true);
        yield return new WaitForSeconds(13.51f);
        SceneManager.LoadScene("Main Menu");
    }
    
}
