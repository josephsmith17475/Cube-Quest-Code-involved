﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinCut : MonoBehaviour
{
    public GameObject world;

    IEnumerator Start()
    {
        world.SetActive(false);
        yield return new WaitForSeconds(5.46f);
        SceneManager.LoadScene("Main Menu");
    }
}
