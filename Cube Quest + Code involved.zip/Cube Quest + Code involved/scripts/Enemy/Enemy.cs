﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;


public class Enemy : MonoBehaviour
{
    public float detectionRadius = 10f;
    public Animator animator;
    public float prepareradius = 2f;
    public int maxHealth = 100;
    public int health;
    public GameObject healthBarUI;
    public Slider slider;
    public Vector3 moveDirection;
    public Rigidbody rb;
    public bool BeingAttacked = false;
    Transform target;
    NavMeshAgent nav;
    public Healthbar HealthBar;
    public int Damage;

    void Start()
    {
        target = enimtarget.instance.player.transform;
        nav = GetComponent<NavMeshAgent>();
        health = maxHealth;
        HealthBar.MaxHealthNum(maxHealth);
    }
    void Update()
    {
        if(BeingAttacked == false)
        {
            FollowPlayer();
        }
        if (health <= 0)
        {
            Destroy(gameObject);
        }

    }
    void FacePlayer()
    {
        Vector3 direction = (target.position - transform.position).normalized;
        Quaternion lookRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * 5f);
    }

    void FollowPlayer()
    {
        float distance = Vector3.Distance(target.position, transform.position);

        if (distance <= detectionRadius)
        {
            nav.SetDestination(target.position);

            if (distance <= nav.stoppingDistance)
            {
                FacePlayer();
            }
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, prepareradius);
    }
    
    IEnumerator OnTriggerEnter(Collider col)
    {
        if (col.tag == "Player")
        {
            GetComponent<NavMeshAgent>().speed = 1;
            animator.SetTrigger("Attack");
            yield return new WaitForSeconds(0.55f);
            GetComponent<NavMeshAgent>().speed = 4;
        }
        if(col.gameObject.name == "sword")
        {
            Debug.Log("hit");
            BeingAttacked = true;
            rb.isKinematic = false;
            TakeDamage(Damage);
            moveDirection = rb.transform.position - col.transform.position;
            rb.AddForce(moveDirection.normalized * +3500);
            yield return new WaitForSeconds(0.10f);
            rb.isKinematic = true;
            BeingAttacked = false;
        }
    }

    void TakeDamage(int damage)
     {
         health -= damage;
         HealthBar.HealthNum(health);
     }

}
